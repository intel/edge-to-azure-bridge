// Copyright Intel Corporation

/**
 * @file
 * @brief Utility function for using a JSON file as the mesage bus config
 */

#ifndef _EII_UTILS_JSON_CONFIG_H
#define _EII_UTILS_JSON_CONFIG_H

#include "eii/utils/config.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Create a configuration object for the EII message bus which pulls config
 * values from the given JSON file.
 *
 * \note Will return NULL if an error is encountered.
 *
 * @param config_file - Path to the JSON configuration file
 * @return config_t
 */
config_t* json_config_new(const char* config_file);

/**
 * Create a configuration object from a json string
 *
 * \note Will return NULL if an error is encountered.
 *
 * @param buffer - json string
 * @return config_t
 */
config_t* json_config_new_from_buffer(const char* buffer);

/**
 * Create a configuration object from a char** array
 *
 * \note Will return NULL if an error is encountered.
 *
 * @param array_items - array
 * @param len - length of array
 * @return config_t
 */
config_t* json_config_new_array(const char** array_items, int len);

// prototypes
void free_json(void* ctx);
config_value_t* get_array_item(const void* array, int idx);
config_value_t* get_config_value(const void* o, const char* key);
bool set_config_value(config_t* config, const char* key, config_value_t* item);


#ifdef __cplusplus
}
#endif

#endif // _EII_UTILS_JSON_CONFIG_H
