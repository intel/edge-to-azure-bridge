# Copyright Intel Corporation
"""EII ConfigManager
"""
