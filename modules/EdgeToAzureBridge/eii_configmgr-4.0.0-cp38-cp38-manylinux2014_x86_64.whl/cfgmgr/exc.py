# Copyright Intel Corporation
"""Custom exceptions used in the Python module
"""


class InitializationFailed(Exception):
    pass
