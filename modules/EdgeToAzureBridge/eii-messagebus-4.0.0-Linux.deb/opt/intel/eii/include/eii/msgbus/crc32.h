// Copyright Intel Corporation

/**
 * @brief Simple CRC32 hashing function
 */

#ifndef _EII_MESSAGE_BUS_CRC32_H
#define _EII_MESSAGE_BUS_CRC32_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// The name of the crc32 method is to msgbus_crc32() to avoid conflicts with
// other libraries.

/**
 * Simple CRC32 function.
 *
 * @param buf - Input stream of bytes
 * @param len - Length of byte stream
 * @return CRC32 value
 */
uint32_t msgbus_crc32(const void* buf, size_t len);

#ifdef __cplusplus
}
#endif

#endif // _EII_MESSAGE_BUS_CRC32_H
