// Copyright Intel Corporation

/**
 * @file
 * @brief Messaging return codes
 */

#ifndef _EII_MESSAGE_BUS_MSGRET_H
#define _EII_MESSAGE_BUS_MSGRET_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Return type for messaging actions.
 */
typedef enum {
    MSG_SUCCESS = 0,
    MSG_ERR_PUB_FAILED = 1,
    MSG_ERR_SUB_FAILED = 2,
    MSG_ERR_RESP_FAILED = 3,
    MSG_ERR_RECV_FAILED = 4,
    MSG_ERR_RECV_EMPTY = 5,
    MSG_ERR_ALREADY_RECEIVED = 6,
    MSG_ERR_NO_SUCH_SERVICE = 7,
    MSG_ERR_SERVICE_ALREADY_EXIST = 8,
    MSG_ERR_BUS_CONTEXT_DESTROYED = 9,
    MSG_ERR_NO_MEMORY = 10,
    MSG_ERR_ELEM_NOT_EXIST = 11,
    MSG_ERR_ELEM_ALREADY_EXISTS = 12,
    MSG_ERR_ELEM_BLOB_ALREADY_SET = 13,
    MSG_ERR_ELEM_BLOB_MALFORMED = 14,
    MSG_RECV_NO_MESSAGE = 15,
    MSG_ERR_SERVICE_INIT_FAILED = 16,
    MSG_ERR_REQ_FAILED = 17,
    MSG_ERR_EINTR = 18,
    MSG_ERR_MSG_SEND_FAILED = 19,
    MSG_ERR_DISCONNECTED = 20,
    MSG_ERR_AUTH_FAILED = 21,
    MSG_ERR_ELEM_OBJ = 22,
    MSG_ERR_ELEM_ARR = 23,
    MSG_ERR_DESERIALIZE_FAILED = 24,
    MSG_ERR_UNKNOWN = 255,
} msgbus_ret_t;

/**
 * Helper method to get the string representation of a message bus return
 * value.
 *
 * @param ret - @c msgbus_ret_t value
 * @return const char* of the return value's name
 */
const char* msgbus_ret_str(msgbus_ret_t ret);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // _EII_MESSAGE_BUS_MSGRET_H
